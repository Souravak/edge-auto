<?php 
$con = mysqli_connect("localhost","root","","prison") or die('Unable To connect');
?>