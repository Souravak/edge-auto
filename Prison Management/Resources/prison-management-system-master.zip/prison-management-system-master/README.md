# Prison-Management-System

Demo : https://youtu.be/0VRYqmD5c_c

1st Step - Import prison db file into your Database ( MySQL or Maria DB ) 

2nd Step - Check the db.php connection parameters such as host,user,password

Username -  battikaran@yahoo.com
password - 1234
